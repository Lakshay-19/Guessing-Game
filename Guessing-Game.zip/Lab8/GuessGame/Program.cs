﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

//Lakshay Punj
//April 15, 2019
//Game to guess number from user

namespace GuessGame
{
    class Program
    {
        static void Main(string[] args)
        {
            //Declaring Variables for progra
            String PlayAgain = string.Empty;

            Random RanNum = new Random();
            int Num = RanNum.Next(1, 50);
            int Guess;
            int Guesses = 0;

            //Testing
            Console.WriteLine(Num);
            do
            {
                Console.Clear();
                do
                {

                    //Asks user for input
                    Console.WriteLine("Enter a number to guess between 1 and 50");
                    Guess = int.Parse(Console.ReadLine());
                    Guesses++;

                    //If/Else statements for guessing
                    if (Guess < Num)
                    {
                        Console.WriteLine("The number is too low. Try Again!");
                    }

                    else if (Guess > Num)
                    {
                        Console.WriteLine("The number to too high. Try Again!");
                    }

                } while (Guess != Num);
                Console.WriteLine("You've guessed the number! Thanks for playing =)");
                Console.WriteLine("Do you want to play again? Enter 1 for Yes Or 2 for No");
             
                PlayAgain = Console.ReadLine();
            } while (PlayAgain == "1" || PlayAgain == "2");
            Console.WriteLine("Thanks for playing!");

        Console.ReadKey();
        }
    }
}